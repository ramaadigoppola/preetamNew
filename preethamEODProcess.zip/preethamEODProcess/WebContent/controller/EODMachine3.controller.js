sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var that;
	var oRouter;
	var oBundle;
	var oModel;
	return Controller.extend("EODProcess.controller.EODMachine3", {
		
		
		onInit:function(){
			that=this;
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 oRouter.getRoute("EODMachine3").attachPatternMatched(this._onObjectMatched, this);
			 
		},
		
		_onObjectMatched:function(){
			//can call the IOT service here
			var oView = this.getView();
			var IotNumber = this.getOwnerComponent().IOTNumber
			//oView.byId("iotNumberId").setText(IotNumber);  // set the selected IOT number
			oModel = new sap.ui.model.json.JSONModel();
			var obj = {
					"d":{
						"results":[
							{"key":"Select Shift","IOT":"Select Shift"},
							{"key":"1710301V32","IOT":"1710301V32"},
							{"key":"1710291V32","IOT":"1710291V32"}
						]
						
					}
					
			};
			oModel.setData(obj);
			
		},
		
	
		
	});
});