sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var that;
	var oRouter;
	var oBundle;
	var oModel;
	return Controller.extend("EODProcess.controller.Dashboard", {
		
		
		onInit:function(){
			that=this;
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 oRouter.getRoute("dashboard").attachPatternMatched(this._onObjectMatched, this);
			 
		},
		
		_onObjectMatched:function(){
			//can call the IOT service here
			oModel = new sap.ui.model.json.JSONModel();
			var obj = {
					"d":{
						"results":[
							{"IOT":"1710301V32"},
							{"IOT":"1710291V32"}
						]
						
					}
					
			};
			oModel.setData(obj);	
		},
		
		onDashboardTilePress:function(){
			if(!this.Iotfragment){
				this.Iotfragment = sap.ui.xmlfragment("EODProcess.fragments.lotNumber",this);
				this.Iotfragment.setModel(oModel);
			}
			this.Iotfragment.open();
		},
		onIotCancel:function(){
			this.Iotfragment.close();
		},
		onIotListPress:function(oEvt){
			var selectedData =oEvt.getParameters().item.getText();
			this.getOwnerComponent().IOTNumber = selectedData;
			this.Iotfragment.close();
			oRouter.navTo("EODMachine2")
		},
	});
});