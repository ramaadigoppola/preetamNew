sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var that;
	var oRouter;
	var oBundle;
	var oModel;
	return Controller.extend("EODProcess.controller.EODMachine2", {
		
		
		onInit:function(){
			that=this;
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 oRouter.getRoute("EODMachine2").attachPatternMatched(this._onObjectMatched, this);
			 
		},
		
		_onObjectMatched:function(){
			//can call the IOT service here
			var oView = this.getView();
			var IotNumber = this.getOwnerComponent().IOTNumber
			oView.byId("iotNumberId").setText(IotNumber);  // set the selected IOT number
			oModel = new sap.ui.model.json.JSONModel();
			var obj = {
					"d":{
						"results":[
							{"key":"Select Shift","IOT":"Select Shift"},
							{"key":"1710301V32","IOT":"1710301V32"},
							{"key":"1710291V32","IOT":"1710291V32"}
						]
						
					}
					
			};
			oModel.setData(obj);
			oView.byId("shiftSelectId").setModel(oModel);
		},
		
		onShiftChange:function(oEvt){
			var oView = this.getView();
			var selectedKey = oEvt.getSource().getSelectedKey(); // if Key Required
			var selectedText = oEvt.getSource().getSelectedItem().getText(); // if Text Required
			
			// call the model with shift as key and bind the success function data to list.
			
			var listModel = new sap.ui.model.json.JSONModel();
			var obj = "";
			if(selectedText == "Select Shift"){
				obj = {
						"d":{
							"results":[
								
							]
							
						}
						
				};
			}else{
			obj = {
					"d":{
						"results":[
							{"whole":"A1","IssuedWeight":"833KG","netWeight":"169KG"},
							{"whole":"A2","IssuedWeight":"733KG","netWeight":"269KG"},
							{"whole":"A3","IssuedWeight":"933KG","netWeight":"369KG"}
						]
						
					}
					
			};
			}
			listModel.setData(obj);
			oView.byId("listID").setModel(listModel);
		},
		onButtonChange:function(oEvt){
			var oView = this.getView();
			var selectedButton = oEvt.getParameters().button.getText();
			if(selectedButton === "Broken"){
				oView.byId("listID").setVisible(false);	
			}else{
				oView.byId("listID").setVisible(true);	
			}
			
		},
		
		
	});
});