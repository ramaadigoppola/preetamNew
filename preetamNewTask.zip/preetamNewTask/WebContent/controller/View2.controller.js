sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/m/MessageToast"
], function(Controller,MessageToast) {
	"use strict";
var oRouter;
var obj;
	return Controller.extend("preetamnewtask.controller.View2", {
		
		onInit:function(){	
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 oRouter.getRoute("secondPage").attachPatternMatched(this._onObjectMatched, this);
		},
			
		_onObjectMatched:function(route){
			var oView = this.getView();
			var dataPage1 = route.getParameters().arguments.trolley;
			
		}
	});
});