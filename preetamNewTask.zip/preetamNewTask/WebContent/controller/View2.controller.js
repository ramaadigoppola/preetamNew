sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/m/MessageToast"
], function(Controller,MessageToast) {
	"use strict";
var oRouter;
var obj;



var i = 0;
	return Controller.extend("preetamnewtask.controller.View2", {
		
		onInit:function(){	
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 oRouter.getRoute("secondPage").attachPatternMatched(this._onObjectMatched, this);
		},
			
		_onObjectMatched:function(route){
			var oView = this.getView();
			var dataPage1 = route.getParameters().arguments.trolley;
			
		},
		
		
		
		onListSelect:function(){
			console.log("test");
		},
		
		onItem:function(){
			var that = this;
			if(!that.fragment){
				that.fragment = sap.ui.xmlfragment("preetamnewtask.fragments.printFragment",that);
			}
			that.fragment.open();	
		},
		
		printSuccess:function(){
			var that = this;
			that.fragment.close();
			if(!that.printfragment){
				that.printfragment = sap.ui.xmlfragment("preetamnewtask.fragments.Dfragment",that);
			}
			that.printfragment.open();	
			
		},
		printCancel:function(){
			this.fragment.close();
		},
		
		onOkPress:function(){
			this.printfragment.close();	
		}
	});
});