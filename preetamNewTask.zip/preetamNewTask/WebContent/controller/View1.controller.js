sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var that;
	var oRouter;
	var oBundle;
	return Controller.extend("preetamnewtask.controller.View1", {
		
		
		onInit:function(){
			that=this;
			 oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 
		},
		
		onDialogPress:function(){
			if(!this.fragment){
				this.fragment = sap.ui.xmlfragment("preetamnewtask.fragments.lotNumber",this);
			}
			this.fragment.open();
		},
		
		onFirstButton:function(oEvt){
			var selectedData = oEvt.getSource().getText();
			
			this.fragment.close();
			oRouter.navTo("secondPage",{trolley:selectedData})
		},
		onIotCancel:function(){
			this.fragment.close();
		}
	});
});